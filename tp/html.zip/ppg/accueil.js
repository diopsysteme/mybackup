 
item_list = document.querySelector('ul.item_list')


function ess(){
	 
document.querySelector('div.pan').classList.toggle('hide')

}

buttons_plus = document.querySelectorAll('button.plus')
/*button_minus = document.querySelectorAll('button.minus')


console.log(buttons_plus)*/

buttons_plus.forEach((item, i) => {
	item.addEventListener('click', ()=>{
		// let item_name = item.parentNode.parentNode.querySelector('article').innerText
		// // console.log(item_name)
		// let li = createItem(item_name)
		// item_list.appendChild(li)

		item_name = item.parentNode.parentNode.querySelector('article').innerText
		li = document.createElement('li')
		li.innerText = item_name
		document.querySelector('ul.item_list').appendChild(li)
	})
})

function plus()
{
	/*let item_name = document.getElementById('label').innerText
 let h3=document.getElementById('prod')
	document.body.insertBefore(h3, item_name)*/
item.querySelector('b').innerText	 
}

button_minus.forEach((item, i) => {

})

function createItem(item){
 let li = document.createElement('li')
 li.innerHTML = item
 return li
}
